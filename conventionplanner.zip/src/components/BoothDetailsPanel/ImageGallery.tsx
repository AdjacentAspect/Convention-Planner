import type { Booth } from "../../types/models";

type Props = {
  booth: Booth | null;
};

function ImageGallery({ booth }: Props) {
  if (!booth) return null;

  return (
    <div style={{ marginTop: 20 }}>
      <h3>Catalogue</h3>

      {booth.images.length === 0 ? (
        <p>No catalogue images.</p>
      ) : (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 8,
          }}
        >
          {booth.images.map((_, index) => (
            <button
              key={index}
              style={{
                padding: 12,
              }}
            >
              🖼 Page {index + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default ImageGallery;